Thrift SmallTalk Software Library

Last updated Nov 2007

License
=======

Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements. See the NOTICE file
distributed with this work for additional information
regarding copyright ownership. The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License. You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied. See the License for the
specific language governing permissions and limitations
under the License.

Contains some contributions under the Thrift Software License.
Please see doc/old-thrift-license.txt in the Thrift distribution for
details.

Library
=======

To get started, just file in thrift.st with Squeak, run thrift -st
on the tutorial .thrift files (and file in the resulting code), and
then:

calc := CalculatorClient binaryOnHost: 'localhost' port: '9090'
calc addNum1: 10 num2: 15

Tested in Squeak 3.7, but should work fine with anything later.
